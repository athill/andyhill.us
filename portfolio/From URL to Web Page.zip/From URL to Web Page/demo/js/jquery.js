$(function() {
	$('#main-header').click(function() {
		alert('header clicked');
	});
	$('.iu-icon').on({
		mouseover: function() {
			$(this).attr('src', 'img/blockiu_crimson.gif');
		},	
		mouseout: function(e) {
			$(this).attr('src', 'img/IU.jpg');		
		}
	});
	$('p').draggable();
});