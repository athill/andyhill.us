document.getElementById("main-header").onclick=function(e){
	alert('header clicked');
};


Array.filter( document.getElementsByClassName('iu-icon'), function(elem){
    elem.onmouseover=function(e) {
    	this.src='img/blockiu_crimson.gif';
    };
   elem.onmouseout=function(e) {
    	this.src='img/IU.jpg';
    };    
});